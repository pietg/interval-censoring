//
//  icm_LS1.cpp
//  interval_censoring_LS
//
//  Created by Piet Groeneboom on 27/08/2025.
//

#include "main.h"

void Compute_lambda(int n, double yy[], double grad[], double lambda[]);
double criterion(int n, int delta[], int first[], int second[], double yy[], double lambda[]);
void gradient(int n, int delta[], int first[], int second[], double yy[], double grad[], double lambda[]);
double f_alpha(int n, int delta[], int first[], int second[], double F[], double yy[], double yy_new[], double *lambda, double alpha);
double golden(int n, int delta[], int first[], int second[], double F[], double yy[], double yy_new[], double lambda[], double (*f)(int,int*,int*,int*,double*,double*,double*,double*,double));


double golden(int n, int delta[], int first[], int second[], double F[], double yy[], double yy_new[], double lambda[], double (*f)(int,int*,int*,int*,double*,double*,double*,double*,double))
{
    double a,b,eps=1.0e-5;
    
    
    a=0;
    b=1;
    
    double k = (sqrt(5.0) - 1.0) / 2;
    double xL = b - k*(b - a);
    double xR = a + k*(b - a);
        
    while (b-a>eps)
    {
        if((*f)(n,delta,first,second,F,yy,yy_new,lambda,xL)<(*f)(n,delta,first,second,F,yy,yy_new,lambda,xR))
        {
            b = xR;
            xR = xL;
            xL = b - k*(b - a);
        }
        else
        {
            a = xL;
            xL = xR;
            xR = a + k * (b - a);
        }
    }
    return (a+b)/2;
    
}

double f_alpha(int n, int delta[], int first[], int second[], double F[], double yy[], double yy_new[], double *lambda, double alpha)
{
    int i;
    
    for (i=1;i<=2*n;i++)
        yy_new[i]=(1-alpha)*F[i]+alpha*yy[i];

    return criterion(n,delta,first,second,yy_new,lambda);
}

void transfer(int first, int last, double a[], double b[])
{
    int    i;
    for (i = first; i<= last;i++)    b[i] = a[i];
}

double criterion(int n, int delta[], int first[], int second[], double yy[], double lambda[])
{
    int i;
    double sum=0;
    
    for (i=1;i<=n;i++)
    {
        sum += SQR(yy[first[i]]-delta[first[i]])/2+SQR(yy[second[i]]-yy[first[i]]-delta[second[i]])/2+SQR(yy[second[i]]-delta[first[i]]-delta[second[i]])/2;
    }
    
    /*for (i=1;i<=n;i++)
    {
        if (yy[i]==0)
            sum -= lambda[0]*yy[i];
        if (yy[n+i]==1)
            sum -= lambda[1]*(1-yy[n+i]);
    }*/
    
    return sum;
}


void gradient(int n, int delta[], int first[], int second[], double yy[], double grad[])
{
    int i;
        
    for (i=1;i<=n;i++)
    {
        grad[i]=grad[n+i]=0;
    }
    // grad contains minus(!) the derivatives of the criterion function w.r.t. the y_i's.
    
    for (i=1;i<=n;i++)
    {
        grad[first[i]] += delta[first[i]]-yy[first[i]];
        grad[first[i]] -= delta[second[i]]-yy[second[i]]+yy[first[i]];
        grad[second[i]] += delta[second[i]]-yy[second[i]]+yy[first[i]];
        grad[second[i]] += delta[first[i]]+delta[second[i]]-yy[second[i]];
    }
}

void Compute_lambda(int n, double yy[], double grad[], double lambda[])
{
    int i;
    
    lambda[0]=lambda[1]=0;
    for (i=1;i<=2*n;i++)
    {
        if (yy[i]==0)
            lambda[0] -= grad[i];
        if (yy[i]==1)
            lambda[1] += grad[i];
    }
}

void weights(int n, double yy[], double w[])
{
    int i;
    
    for (i=1;i<=2*n;i++)
        w[i]=2;
}


void cumsum(int n, double yy[], double w[], double cumw[], double cs[], double grad[], double *lambda)
{
    int  i;
    
    cumw[0]=0;
    cs[0]=0;
    
    for (i=1;i<=2*n;i++)
    {
        cumw[i] = cumw[i-1]+w[i];
        cs[i]   = cs[i-1]+w[i]*yy[i]+grad[i];
    }
}


void convexminorant(int n, double cumw[], double cs[], double yy[])
{
    int    i,j,m;
    
    cumw[0]=0;
    cs[0]=0;
    yy[0]=0;
    
    for (i=1;i<=2*n;i++)
    {
        yy[i] = (cs[i]-cs[i-1])/(cumw[i]-cumw[i-1]);
        if (yy[i-1]>yy[i])
        {
            j = i;
            while ((yy[j-1] > yy[i]) && (j>1))
            {
                j--;
                yy[i] = (cs[i]-cs[j-1])/(cumw[i]-cumw[j-1]);
                for (m=j;m<i;m++)
                    yy[m] = yy[i];
            }
        }
    }
    
    for (i=1;i<=2*n;i++)
    {
        if (yy[i]<=0)
            yy[i]=0;
        if (yy[i]>=1)
            yy[i]=1;
    }
}

int fenchelviol(int n, double yy[], double grad[], double lambda[], double tol, double *inprod, double *partsum)
{
    double    sum,sum2;
    int    i;
    int    fenchelvioltemp;
    
    fenchelvioltemp = 0;
    
    sum=sum2 = lambda[0];
    
    for (i=1;i<=2*n;i++)
    {
        sum += grad[i];
        if (sum < sum2)
            sum2 = sum;
    }
    
    sum = -lambda[1];

    for (i=1;i<=2*n;i++)
        sum += grad[i]*yy[i];
    
    *inprod = sum;
    *partsum = sum2;
    
    if ((fabs(sum) > tol) || (sum2 < -tol) ) fenchelvioltemp = 1;
    
    return fenchelvioltemp;
}

void isoreg(int n, int delta[], int first[], int second[], double data0[], double F[], double grad[], int *iterations)
{
    int i,iter;
    double *yy,*yy_new,alpha,inprod,partsum;
    double *minorant,*w,*cs,*cumw,*lambda,a;
    double tol=1.0e-8;
    
    alpha=1;
    
    lambda = new double[2];
    yy = new double[2*n+2];
    yy_new = new double[2*n+2];
    minorant = new double[2*n+2];
    
    yy[0]=yy_new[0]=0.0;
    yy[2*n+1]=yy_new[2*n+1]=1;
    
    cs   = new double[2*n+2];
    cumw    = new double[2*n+2];
    w    = new double[2*n+2];
    
    lambda[0]=lambda[1]=0;
    
    gradient(n,delta,first,second,F,grad);
    Compute_lambda(n,F,grad,lambda);
    iter=0;
    
    //printf("lambda's: %15.10f = %15.10f\n",lambda[0],lambda[1]);
    
    while (fenchelviol(n,F,grad,lambda,tol,&inprod,&partsum) && iter<200)
    {
        iter++;
        transfer(1,2*n,F,yy);
        weights(n,yy,w);
        cumsum(n,yy,w,cumw,cs,grad,lambda);
        convexminorant(n,cumw,cs,yy);
        
        //alpha = golden(n,delta,first,second,F,yy,yy_new,lambda,f_alpha);
         //for (i=1;i<=2*n;i++)
         //F[i] = alpha*yy[i]+(1-alpha)*F[i];
        
        for (i=1;i<=2*n;i++)
            F[i]=yy[i];
        
        gradient(n,delta,first,second,F,grad);
        
        Compute_lambda(n,F,grad,lambda);
        
        //printf("lambda's and alpha: %15.10f  %15.10f  %10.5f\n",lambda[0],lambda[1],alpha);
        //printf("%5d  %15.10f  %15.10f   %10.5f\n",iter,inprod,partsum,alpha);
    }
    
    
    //printf("lambda's: %15.10f  %15.10f\n\n",lambda[0]/n,lambda[1]/n);
    
    /*a=lambda[0]/n;
    for (i=1;i<=2*n;i++)
    {
        a +=grad[i]/n;
        printf("%15.10f  %15.10f\n",data0[i],a);
    }*/
    
    //printf("%5d  inprod = %15.10f     partsum = %15.10f\n",iter,inprod,partsum);
    
    /*minorant[0]=0;
    outputfile=fopen("minorant.txt","w");
    rewind(outputfile);
    
    for (i=0;i<=2*n;i++)
    {
        if (i>0)
            minorant[i]= minorant[i-1]+yy[i]*w[i];
        fprintf(outputfile,"%15.10f   %15.10f   %15.10f\n",cumw[i],lambda[0]+cs[i],minorant[i]);
    }
        
    fclose(outputfile);*/
    
    *iterations = iter;
     
    //printf("\nalpha and dnumber iterations %15.10f  %5d\n",alpha,iter);
    
    //printf("\n");
    
    //for (i=1;i<=2*n;i++)
        //printf("%15.10f  %15.10f  %15.10f\n",cs[i],grad[i],yy[i]);
    
    //printf("\n");
    
    //printf("lambda's: %15.10f  %15.10f\n",lambda[0],lambda[1]);

    delete[] yy; delete[] yy_new; delete[] lambda;
    delete[] cs; delete[] cumw;  delete[] w; delete[] minorant;
    
    //for (i=1;i<=n;i++)
        //printf("%15.10f     %15.10f\n",cumw[i],cs[i]);
}
