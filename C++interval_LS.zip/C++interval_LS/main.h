//
//  main.h
//  interval_censoring_LS
//
//  Created by Piet Groeneboom on 15/08/2025.
//

#include <iostream>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <math.h>
#include <time.h>
#include <random>
#include <string.h>

using namespace std;

#define SQR(x) ((x)*(x))

using namespace std;

#define SQR(x) ((x)*(x))

typedef struct
{
    double x;
    int index;
    int delta[3];
}
data0_object;

typedef struct
{
    double x;
    int i;
    int j;
}
indexed_data_object;


typedef struct
{
    double x;
    double y;
}
data_object;

typedef struct
{
    double x;
    int index;
}
data_object2;

typedef struct
{
    double x;
    int index;
    int delta;
}
data_object3;

typedef struct
{
    int i;
    int j;
}
index_object;

void Interior_point(int n, double F[],  double F_new[],
                    double b[], int delta[], int first[], int second[], double grad[], double **Hessian, double *phif, double *norm);
double F0(double a, double x);
int compute_LS(int n, double **data, int **delta, double F[], double tt[], double pp[], int *iterations);
void isoreg(int n, int delta[], int first[], int second[], double data0[], double F[], double grad[], int *iterations);
int compute_MLE(int n, double **data, double F[], double tt[], double pp[], int *iterations);
void isoreg(int n, int first[], int second[], double F[], double grad[], int *iterations);
void sort_data0(int m, double data0[], int index0[], int **delta);
void sort_data_delta2(int n, double Z[], int ind[]);
int compute_LS(int n, double **data, int **delta, double F[], double tt[], double pp[], int *iterations);
void isoreg(int n, int first[], int second[], int **delta, double F[], double grad[], int *iterations);
double criterion(int n, int **delta, int first[], int second[], double yy[], double lambda[]);
double golden(int n, int **delta, int first[], int second[], double F[], double yy[], double yy_new[], double lambda[], double (*f)(int,int**,int*,int*,double*,double*,double*,double*,double));

double f_alpha(int n, int **delta, int first[], int second[], double F[], double yy[], double yy_new[], double *lambda, double alpha);

void   data_exp(int n, double **data, int **delta, int seed);
int compute_LS2(int n, double **data, double F[], double tt[], double pp[], int *iterations);
void cumsum(int n, double yy[], double w[], double cumw[], double cs[], double grad[], double *lambda);
double f_alpha(int n, int **delta, double F[], double yy[], double yy_new[], double *lambda, double alpha);
void weights(int n, double yy[], double w[]);
double criterion(int n, int **delta, double yy[]);
double criterion(int n, int **delta, double yy[], double *lambda);
void gradient(int n, int **delta, double yy[], double grad[], double *lambda);
void isoreg(int n, int **delta, double F[], double grad[], double mu, int *iterations);
void Interior_point(int n, double F[],  double F_new[],
                    double b[], int **delta, double grad[], double **Hessian, double *phif, double *norm);
void cumsum(int n, double yy[], double w[], double cumw[], double cs[], double grad[]);
double golden(int n, int **delta, double F[], double yy[], double yy_new[], double lambda[], double (*f)(int,int**,double*,double*,double*,double*,double));

double golden(int n, int **delta, double F[], double yy[], double yy_new[], double mu, double (*f)(int,int**,double*,double*,double*,double,double));

int compute_LS_interior(int n, double **data, double F[], double tt[], double pp[], int *iterations);
int compute_mle_Bertien(int n, double **data, double F[], double tt[], double pp[]);
int fenchelviol(int n1, double yy[], double grad[], double tol, double *inprod, double *partsum);

double golden(int n1, int **N, int **ind_second, int *index_end, double F[], double yy[], double yy_new[], double (*f)(int,int**,int**,int*,double*,double*,double*,double));
double f_alpha(int n, int **delta, double F[], double yy[], double yy_new[], double alpha);
//double criterion(int n1, int **N, int **ind_second, int *index_end, double yy[]);
double criterion(int n, int **delta, double yy[], double lambda[]);
double criterion(int n, int **delta, double yy[],  double mu);

void isoreg(int n1, int **N, int **ind_second, int *index_end, double F[], double grad[], int *iterations);
void cumsum(int n, double yy[], double cumw[], double cs[], double grad[]);
//void gradient(int n, int **delta, double yy[], double grad[]);
void gradient(int n, int **delta, double yy[], double grad[], double mu);
void gradient(int n, int **delta, double yy[], double grad[], double lambda[]);
void Compute_lambda(int n, double **data, double yy[], double *lambda);
void compute_Hessian(int n, int **delta, double yy[], double **Hessian, double mu);

void weights(int n1, int **N, int **ind_second, int *index_end, double yy[], double w[], double mu);
void gradient(int n1, int **N, int **ind_second, int *index_end, double yy[], double grad[], double mu);
double criterion(int n1, int **N, int **ind_second, int *index_end, double yy[], double mu);
double armijo(int n1, int **N, int **ind_second, int *index_end, double grad[], double F[], double yy[], double yy_new[], double mu);
double f_alpha(int n1, int **N, int **ind_second, int *index_end, double F[], double yy[], double yy_new[], double mu, double alpha);
double golden(int n1, int **N, int **ind_second, int *index_end, double F[], double yy[], double yy_new[], double mu, double (*f)(int,int**,int**,int*,double*,double*,double*,double,double));
int compute_LS(int n, double **data, double F[], double tt[], double pp[], int *iterations);
void isoreg(int n, int **delta, double F[], double grad[], int *iterations);
void sort_data_delta(int n, double Z[], int **delta);
double criterion(int n, int **delta, double yy[], double *lambda);
void lubksb(double **a, int n1, int *indx, double b[]);
void ludcmp(double **a, int n1, int *indx, double *d, double vv[]);
void ComputeFeasibleStep(int n1,  double F[], double F_new[], double d[]);

void InnerLoop(int NumIterations,int n, double F[],  double F_new[],
               double b[], int **delta, double grad[], double **Hessian, double *phif, double *norm, double mu);
void Interior_point(int n1, double F[],  double F_new[],
                    double b[], int **delta, double grad[], double **Hessian, double *phif, double *norm);
    
int     compare (const void * a, const void * b);
int     compare2(const void *a, const void *b);
void sort_data1(int m, double data0[], int delta[]);
double armijo(int n1, int **N, int **ind_second, int *index_end, double grad[], double F[], double yy[], double yy_new[]);
int     armijoviol1(int m, double eps, double phi_old, double phi_new,
                double grad_old[], double F_old[], double F_new[]);
int     armijoviol2(int m, double eps, double phi_old, double phi_new,
                double grad_old[], double F_old[], double F_new[]);
void mean_variance(int NumIt, int ngrid, double **df_on_grid, double *mean, double *var);
double  KK(double x);
double  KK2(double x);
double  K(double x);
double  K2(double x);
double  dens_estimate(double A, double B,  int njumps, double jumploc[], double p[], double u, double h);
double  dens_estimate_conv(double A, double B,  int m, double t[], double p[], double u, double h);
double  bdf(double A, double B,  int m, double tt[], double p[], double u, double h);
double  bdf_conv(double B, int m, double data[], double p[], double u, double h);
double  dens_estimate2(int n, double A, double B1, double B2, double data1[], double data2[], double u, double v, double h1, double h2);

void Interior_point(int n, double F[],  double F_new[],
                    double b[], int delta[], int first[], int second[], double grad[], double *phif, double *norm);
void    transfer(int first, int last, double a[], double b[]);
int compute_mle(int n, double **data, double F[], double tt[], double pp[], int *iterations);
int compute_mle_CS(int n, double **data, double FF[], double tt[], double pp[]);
void convexminorant(int n1, double cumw[], double cs[], double yy[]);
void sort_data1(int m, double data0[], int delta[]);
double MSE_dens(int n, int n1, int ngrid, double grid[], double M1, int B, double data1[], double data2[], double data3[], double data_infection[], double data1_bootstrap[], double data2_bootstrap[], double tt[], double pp[], double tt_bootstrap[], double pp_bootstrap[], double F_bootstrap[], double h1, double h2);
double  MSE_dens2(int ngrid, double B, double h);
int     compare (const void * a, const void * b);
double  bdf(double B, int m, double data[], double p[], double u, double h);
double  bdf_conv(double B, int m, double data[], double p[], double u, double h);
double dens_estimate_conv(double A, double B,  int m, double t[], double p[], double u, double h);
double criterion2(double A, double B, int n1, double tt[], double pp[], double u, double v, double h);
double golden(double A, double B, int m, double t[], double p[], double v, double h,
              double (*f)(double,double,int,double*,double*,double,double,double));

double  Weibull_df(double a, double b, double M1, double x);
double  Weibull_dens(double a, double b, double M1, double x);
double  Weibull_inv(double a, double b, double M1, double u);
double  lognormal_inv(double a, double b, double M1, double u);
double log_normal_df(double a, double b, double M1, double x);
void    data_exp(int n, double **data, int seed);
void    sort_data(int n, double data1[], double data2[]);
void    sort_data0(int m, double data0[], int index0[]);
void    sort_index(int n, int index1[]);
void    getData(FILE *in, int n, double **data);
void    data_bootstrap(int n, int n1, double M1, double data3[], double **bootstrap_data,double tt[], double pp[], double h, int seed);
void   data_bootstrap(int n, int m, double **data, double **data_bootstrap, int seed);
//void data_bootstrap(int n, int n1, double M1, double data3[], double **data_bootstrap, double tt[], double pp[], double h, int seed);
void    data_infect(int n, double data3[], double data_infection[], int seed);
double  data_smooth(int n1, double M1, double tt[], double pp[], double h);
void    getData_Lauer(FILE *in, int n, double data_exit_L[], double data_exit_R[], double data_symp_L[], double data_symp_R[]);
//void  getData_Lauer(FILE *in, int n, double data1[], double data2[], double data3[]);
void    getData_Lauer2(FILE *in, int n, double data1[], double data2[], double data3[]);

void    mean_variance(int NumIt, double quantile[], double *mean, double *var);
double criterion_Weibull(int n, double M1, double data1[], double data2[], double alpha[]);
double  criterion_lognormal(int n, double M1, double data1[], double data2[], double alpha[]);

double  best_nearby(int n, int m, double M1, double data1[], double data2[], double delta[], double point[], double prevbest, double f(int n, double M1, double data1[], double data2[], double alpha[]), int *funevals);

void data_bootstrap(int n, int m, double M1, double M, double data_exit[], double reduced_var[], double **data, double **bootstrap_data, double tt[], double pp[], double h, int seed);
void reduce_variables(int n, double M1, double data_exit[], double **data, double reduced_var[]);

double KK2(double x, double c);
double bdf_conv(double A, double B, int m, double data[], double p[], double u, double h1, double h0);





