     B<-read.table("LS.txt")
	   x<-B[,1]
	   y<-B[,2]
	   
	   C<-read.table("LS1.txt")
	   x1<-C[,1]
	   y1<-C[,2]

	   
     	#f <- function(x) {(1-exp(-x))/(1-exp(-2))}
     	f <- function(x){x}
     	x0 <-seq(0,1,by=0.01)
   		y0<-f(x0)
	   	
	   plot(c(-1000,-1000),xlim=c(0,1), ylim=c(0,1), main= "",ylab="",xlab="",bty="n",las=1)
	   lines(x,y,lwd=2,col="blue",type='s')
	   #lines(x1,y1,lwd=2,lty=2,col="red",type='s')
	   lines(x0,y0,lwd=2)
		
		
		
		
	
	    