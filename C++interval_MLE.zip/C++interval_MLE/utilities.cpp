//
//  utilities1.cpp
//  interval_censoring_LS
//
//  Created by Piet Groeneboom on 27/08/2025.
//


#include "main.h"

void sort_data0(int m, double data0[], int index0[]);
void sort_data0(int m, double data0[], int *delta0, int index0[]);

double F0(double a, double x)
{
    if (x>0 && x<= a)
        return (1-exp(-x))/(1-exp(-a));
    else
    {
        if (x>a)
            return 1;
        else
            return 0;
    }
}


int compute_MLE(int n, double **data, double F[], double tt[], double pp[], int *iterations)
{
    int i,j,m,n1,*first,*second;
    int *ind;
    double *grad,*F1,*F_new,phif,*b,*tt1;
    int *index0,indexmin=0,indexmax=0;
    double min,max_obs1,min_obs2;
    double *data0;
    
    grad = new double[2*n+2];
    F1 = new double[3*n+2];
    F_new = new double[3*n+2];
    data0 = new double[2*n+2];
    b = new double[2*n+2];
    
    
    first = new int[2*n+2];
    second = new int[2*n+2];
    ind = new int[2*n+2];
    
    for (i=0;i<=2*n+1;i++)
        grad[i]=data0[i]=0;
    
    for (i=0;i<n;i++)
    {
        data0[i]=data[i][0];
        data0[n+i]=data[i][1];
    }
    
    index0 = new int[2*n+2];
    
    sort_data0(2*n,data0,index0);
    sort_index(2*n,index0);
    
    // index0 maps indices of data  to indices of data0
    // The indices of delta[i][1] are shifted to n+i
    // We have: data0[index0[i]]=data[i][0] and data0[index0[n+i]]=data[i][1], for i=0,..,n-1.
    
    min_obs2= 1.0e10;
    for (i=0;i<n;i++)
    {
        if (data[i][1]<min_obs2)
        {
            min_obs2 = data[i][1];
            indexmin=i;
        }
    }
    
    max_obs1= 0;
    for (i=0;i<n;i++)
    {
        if (data[i][0]>max_obs1)
        {
            max_obs1 = data[i][0];
            indexmax=i;
        }
    }
    
    //printf("min_obs2 and max_obs1 = %15.10f   %15.10f\n",min_obs2,max_obs1);
    
    /*printf("min_obs2 and max_obs1: %15.10f  %15.10f\n\n",min_obs2,max_obs1);
    printf("indexmin and indexmax: %d  %d\n\n",n+indexmin+1,indexmax+1);*/
    
    // ind maps the indices ind0 to the indices of the array tt
    
    tt[0]=0.0;
    ind[0] = 0;
    
    j=0;
    
    for (i=0;i<2*n;i++)
    {
        if (data0[i]<min_obs2)
            ind[i]=0;
        else
        {
            if (data0[i]>=min_obs2 && data0[i]<=max_obs1)
            {
                if (i>0 && data0[i]>data0[i-1])
                    j++;
                ind[i]=j;
                tt[j]=data0[i];
            }
        }
    }
    
    n1=j;
    
    /*for (i=1;i<=n1;i++)
        printf("%15.10f\n",tt[i]);
    
    printf("\n\n");
    
    for (i=0;i<2*n;i++)
        printf("%15.10f\n",data0[i]);*/
    
    min=data0[2*n-1];
    
    for (i=2*n-1;i>=0;i--)
    {
        if (data0[i]>max_obs1)
        {
            ind[i]=n1+1;
            if (data0[i]<min)
                min=data0[i];
        }
    }
    
    tt[n1+1]=min;
    
   // printf("indexmin and indexmax: %d  %d\n\n",ind[index0[indexmin]],ind[index0[indexmax]]);
    
    for (i=0;i<n;i++)
    {
        first[i+1]=ind[index0[i]];
        second[i+1]=ind[index0[n+i]];
    }
    
     /*for (i=0;i<n;i++)
        printf("%5d  %5d   %5d    %5d\n",index0[i],index0[n+i],ind[index0[i]],ind[index0[n+i]]);
    
    printf("\n");
    
    for (i=0;i<2*n;i++)
        printf("%15.10f\n",data0[i]);
     
    printf("\n");
    
    for (i=0;i<2*n;i++)
        printf("%5d  %5d   %5d    %5d\n",index0[i],index0[n+i],first[i+1],second[i+1]);*/
    F[0]=0;
    F[n1+1]=1;
    
    for (i=1;i<=n1;i++)
        F[i]=i*1.0/(n1+1);
    
    for (i=0;i<=n1+1;i++)
        F1[i]=F_new[i]=F[i];
    
    //Interior_point(n,F,F_new,b,delta0,first,second,grad,&phif,&norm);
    
    isoreg(n,n1,first,second,F,grad,iterations);
    
    tt1= new double[n1+2];
    
    j=0;
    
    for (i=1;i<=n1+1;i++)
    {
        if (F[i]>F[i-1])
        {
            j++;
            F1[j]=F[i];
            tt1[j]=tt[i];
        }
    }
    
    m=j;
    
    
    for (i=1;i<=m;i++)
    {
        F[i] = F1[i];
        tt[i]=tt1[i];
        pp[i] = F[i]-F[i-1];
    }
    
    delete[] data0;
    delete[] grad;
    delete[] F1;
    delete[] tt1;
    delete[] F_new;;
    delete[] b;
    
    delete[] index0; delete[] ind;
    delete[] first; delete[] second;
    
    return m;
}

void sort_data0(int m, double data0[], int index0[])
{
    int i;
    data0_object *obs;
    
    obs = new data0_object[m];
    
    for (i=0;i<m;i++)
    {
        obs[i].x = data0[i];
        obs[i].index = i;
    }
    
    qsort(obs,m,sizeof(data0_object),compare2);
    
    for (i=0;i<m;i++)
    {
        data0[i]=obs[i].x;
        index0[i]=obs[i].index;
    }
    
    delete[] obs;
}


void sort_data1(int m, double data0[], int delta[])
{
    int i;
    data0_object *obs;
    
    obs = new data0_object[m];
    
    for (i=0;i<m;i++)
    {
        obs[i].x = data0[i];
        obs[i].index = delta[i];
    }
    
    qsort(obs,m,sizeof(data0_object),compare2);
    
    for (i=0;i<m;i++)
    {
        data0[i]=obs[i].x;
        delta[i]=obs[i].index;
    }
    
    delete[] obs;
}

double criterion2(double A, double B, int n1, double tt[], double pp[], double u, double v, double h)
{
    return fabs(bdf(A,B,n1,tt,pp,u,h)-v);
}


int compare(const void * a, const void * b)
{
  return ( *(int*)a - *(int*)b );
}

int compare2(const void *a, const void *b)
{
    double x = *(double*)a;
    double y = *(double*)b;
    
    if (x < y)
        return -1;
    if (x > y)
        return 1;
    return 0;
}

void sort_data_delta2(int n, double Z[], int ind[])
{
    int i;
    data_object2 *obs;
    
    obs = new data_object2[2*n];
    
    for (i=0;i<2*n;i++)
    {
        obs[i].x = Z[i+1];
        obs[i].index = i+1;
    }
    
    qsort(obs,2*n,sizeof(data_object2),compare2);
    
    for (i=0;i<2*n;i++)
    {
        Z[i+1]=obs[i].x;
        ind[i+1] = obs[i].index;
    }
    
    //for (i=1;i<=2*n;i++)
        //printf("%15.10f   %5d\n",Z[i],ind[i]);

    delete[] obs;
}


double golden(double A, double B, int m, double t[], double p[], double v, double h,
              double (*f)(double,double,int,double*,double*,double,double,double))
{
    double a,b,eps=1.0e-6;
    
    a=A;
    b=B;
    
    double k = (sqrt(5.0) - 1.0) / 2;
    double xL = b - k*(b - a);
    double xR = a + k*(b - a);
    
    while (b-a>eps)
    {
        if ((*f)(A,B,m,t,p,xL,v,h)<(*f)(A,B,m,t,p,xR,v,h))
        {
            b = xR;
            xR = xL;
            xL = b - k*(b - a);
        }
        else
        {
            a = xL;
            xL = xR;
            xR = a + k * (b - a);
        }
    }
    return (a+b)/2;
    
}

void sort_data_delta(int n, double Z[], int **delta)
{
    int i;
    indexed_data_object *obs;
    
    obs = new indexed_data_object[n];
    
    for (i=0;i<n;i++)
    {
        obs[i].x = Z[i];
        //obs[i].i = delta[i][0];
        //obs[i].j = delta[i][1];
    }
    
    qsort(obs,n,sizeof(indexed_data_object),compare2);
    
    for (i=0;i<n;i++)
    {
        Z[i+1]=obs[i].x;
        //delta[i+1][0]=obs[i].i;
        //delta[i+1][1]=obs[i].j;
    }
    
    delete[] obs;
}

void sort_data0(int m, double data0[], int *delta0, int index0[])
{
    int i,j;
    data_object3 *obs;
    
    obs = new data_object3[m];
    
    for (i=0;i<m;i++)
    {
        obs[i].x = data0[i];
        obs[i].index = i;
        obs[i].delta  = delta0[i];
    }
    
    qsort(obs,m,sizeof(data_object2),compare2);
    
    for (i=0;i<m;i++)
    {
        data0[i]=obs[i].x;
        index0[i]=obs[i].index;
        delta0[i] = obs[i].delta;
    }
    
    delete[] obs;
}

void sort_data0(int m, double data0[], int index0[], int **delta)
{
    int i,j;
    data0_object *obs;
    
    obs = new data0_object[m];
    
    for (i=0;i<m;i++)
    {
        obs[i].x = data0[i];
        obs[i].index = i;
        for (j=0;j<3;j++)
            obs[i].delta[j]= delta[i][j];
    }
    
    qsort(obs,m,sizeof(data0_object),compare2);
    
    for (i=0;i<m;i++)
    {
        data0[i]=obs[i].x;
        index0[i]=obs[i].index;
        for (j=0;j<3;j++)
            delta[i][j] = obs[i].delta[j];
    }
    
    delete[] obs;
}

void sort_data(int m, double data1[], double data2[])
{
    int i;
    data_object *obs;
    
    obs = new data_object[m];
    
    for (i=0;i<m;i++)
    {
        obs[i].x = data1[i];
        obs[i].y = data2[i];
    }
    
    qsort(obs,m,sizeof(data_object),compare2);
    
    for (i=0;i<m;i++)
    {
        data1[i]=obs[i].x;
        data2[i]=obs[i].y;
    }
    
    delete[] obs;
}

void sort_index(int m, int index1[])
{
    int i;
    index_object *obs;
    
    obs = new index_object[m];
    
    for (i=0;i<m;i++)
    {
        obs[i].i = index1[i];
        obs[i].j = i;
    }
    
    qsort(obs,m,sizeof(index_object),compare);
    
    for (i=0;i<m;i++)
        index1[i]=obs[i].j;
    
    delete[] obs;
}

void mean_variance(int count, int ngrid, double **df_on_grid, double *mean, double *var)
{
    int i,j;
    
    for (j=1;j<=ngrid;j++)
    {
        mean[j]=0;
        var[j]=0;
    }
    
    for (i=1;i<=count;i++)
    {
        for (j=1;j<=ngrid;j++)
            mean[j] += df_on_grid[i][j];
    }
    
    for (j=1;j<=ngrid;j++)
        mean[j] /= count;
        
    for (i=1;i<=count;i++)
    {
        for (j=1;j<=ngrid;j++)
            var[j] += SQR(df_on_grid[i][j]-mean[j])/count;
    }
}

double bdf(double A, double B, int m, double t[], double p[], double u, double h)
{
    int       k;
    double    t1,t2,t3,sum;
    
    sum=0;
    
    for (k=1;k<=m;k++)
    {
        t1=(u-t[k])/h;
        t2=(u+t[k]-2*A)/h;
        t3=(2*B-u-t[k])/h;
        sum+= (KK(t1)+KK(t2)-KK(t3))*p[k];
        //sum+= KK(t1)*p[k];
    }

    return fmax(sum,0);
}

double bdf_conv(double B, int m, double data[], double p[], double u, double h)
{
    int            i;
    double        t1,t2,t3,sum;
    
    sum=0;
    
    for (i=1;i<=m;i++)
    {
        t1=(u-data[i])/h;
        t2=(u+data[i])/h;
        t3=(2*B-u-data[i])/h;
        
        sum+= (KK2(t1)+KK2(t2)-KK2(t3))*p[i];
        //sum+= KK2(t1)*p[i];
        
    }
    
    return fmax(0,sum);
}


double KK(double x)
{
    double u,y;
    
    u=x*x;
    
    if (u<=1)
        y = (16.0 + 35*x - 35*pow(x,3) + 21*pow(x,5) - 5*pow(x,7))/32.0;
    else
    {
        if (x>1)
            y=1;
        else
            y=0;
        
    }
    
    return y;
}

double K2(double x)
{
    double y;
    
    y=0;
    
    if (x<=-2)
        y=0;
    
    if (x>=2)
        y=0;
    
    if (x>-2 && x<0)
        y=(35*pow(2 + x,7)*(320 + x*(-1120 + x*(1616 + x*(-1176 + x*(404 + 5*(-14 + x)*x))))))/1757184.0;
    
    
    if (x>=0 && x<2)
        y = -(35*pow(-2 + x,7)*(320 + x*(1120 + x*(1616 + x*(1176 + x*(404 + 5*x*(14 + x)))))))/1757184.0;
   
    return y;
}

double KK2(double x)
{
    double y;
    
    y=0;
    
    if (x<=-2)
        y=0;
    
    if (x>=2)
        y=1;
    
    if (x>-2 && x<0)
        y=pow(2.0 + x,8)*(6864 - 16256*x + 16976*SQR(x) - 9440*pow(x,3) + 2690*pow(x,4) - 400*pow(x,5) + 25*pow(x,6))/3514368.0;
    
    
    if (x>=0 && x<2)
        y = 0.5 + 350*x/429.0 - 35*pow(x,3)/66.0 + 7*pow(x,5)/24.0 - 5*pow(x,7)/32.0 + 35*pow(x,8)/512.0 - 7*pow(x,10)/1536.0 + 35*pow(x,12)/135168.0 - 25*pow(x,14)/3514368.0;
    
    return y;
}

double K(double x)
{
    double u,y;
    
    u=x*x;
    
    if (u<=1)
        y=(35.0/32)*pow(1-u,3);
    else
        y=0.0;
    
    return y;
}

/*double MSE_dens(int n, int m, int ngrid, double grid[], double M1, int B, double data1[],double data2[], double data3[], double data_infection[], double **bootstrap_data, double tt[], double pp[], double tt_bootstrap[], double pp_bootstrap[], double F_bootstrap[], double h1, double h2)
{
    int i,iter,m_bootstrap,seed;
    double MSE,*grad,*cumw;
    double *data_incub;
    
    grad = new double[2*n+1];
    cumw = new double[2*n+1];
    data_incub = new double[n];
    
    MSE=0;
    for (iter=1;iter<=B;iter++)
    {
        seed = rand();
        
        //data_bootstrap(n,n,data1,data2,data1_bootstrap,data2_bootstrap,seed);
        
        //data_bootstrap(n,m,M1,data,bootstrap_data,tt,pp,h1,seed);
        
        //data_exp(n,a,b,M1,30,bootstrap_data,data3,data_incub,seed);
        
        m_bootstrap = compute_mle(n,bootstrap_data,F_bootstrap,
                                 tt_bootstrap,pp_bootstrap,cumw,grad);
    
        
        for (i=1;i<=ngrid;i++)
            MSE += SQR(dens_estimate(0,M1,m_bootstrap,tt_bootstrap,pp_bootstrap,grid[i],h2)
                       -dens_estimate(0,M1,m,tt,pp,grid[i],h1))*0.1;
            //MSE += SQR(dens_estimate(0,M1,m_bootstrap,tt_bootstrap,pp_bootstrap,grid[i],h2)
                       //-Weibull_dens(a,b,M1,grid[i]))*0.1;
        
    }
    
    delete[] grad; delete[] cumw; delete[] data_incub;
    return MSE/B;
}*/

double dens_estimate(double A, double B,  int m, double t[], double p[], double u, double h)
{
    int k;
    double      t1,t2,t3,sum;
    
    sum=0;
    
    for (k=1;k<=m;k++)
    {
        t1=(u-t[k])/h;
        t2=(u+t[k]-2*A)/h;
        t3=(2*B-u-t[k])/h;
        sum += (K(t1)+K(t2)+K(t3))*p[k]/h;
        //sum += K(t1)*p[k]/h;
    }
    
    return fmax(0,sum);
}



/*double log_normal_df(double a, double b, double M1, double x)
{
    if (x>0 && x<= M1)
        return (0.5+0.5*erf((log(x)-a)/(b*sqrt(2))))/(0.5+0.5*erf((log(M1)-a)/(b*sqrt(2))));
        //return (0.5+0.5*erf((log(x)-a)/(b*sqrt(2))));
    else
    {
        if (x>M1)
            return 1;
        else
            return 0;
    }
}*/




double Weibull_df(double a, double b, double M1, double x)
{
    if (x>0 && x<= M1)
        return (1-exp(-b*pow(x,a)))/(1-exp(-b*pow(M1,a)));
    else
    {
        if (x>M1)
            return 1;
        else
            return 0;
    }
}

double Weibull_inv(double a, double b, double M1, double u)
{
    double c,v;
    
    c= 1-exp(-b*pow(M1,a));
    //c=1;
 
    if (u>=1)
        return M1;
    if (u<=0)
        return 0;
    
    v = pow(b,-1.0/a)*pow(log(1/(1-c*u)),1.0/a);
 
    return v;
}

/*double lognormal_inv(double a, double b, double M1, double u)
{
    double v,c;
 
    
    if (u>=1)
        return M1;
    if (u<=0)
        return 0;
    
    c = 0.5+0.5*erf((log(M1)-a)/(b*sqrt(2)));
    //v = exp(a+boost::math::erf_inv(2*c*u-1)*b*sqrt(2));
    v = exp(a+boost::math::erf_inv(2*u-1)*b*sqrt(2));
 
    return v;
}*/
