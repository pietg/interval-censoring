//
//  icm_LS1.cpp
//  interval_censoring_LS
//
//  Created by Piet Groeneboom on 27/08/2025.
//

#include "main.h"

double criterion(int n, int first[], int second[], double yy[]);
void gradient(int n, int n1, int first[], int second[], double yy[], double grad[]);
double f_alpha(int n, int n1, int first[], int second[], double F[], double yy[], double yy_new[], double alpha);
double golden(int n, int n1, int first[], int second[], double F[], double yy[], double yy_new[], double (*f)(int,int*,int*,double*,double*,double*,double));
void weights(int n, int n1, int first[], int second[], double grad[], double w[]);


double golden(int n, int n1, int first[], int second[], double F[], double yy[], double yy_new[], double (*f)(int,int,int*,int*,double*,double*,double*,double))
{
    double a,b,eps=1.0e-5;
    
    
    a=0;
    b=1;
    
    double k = (sqrt(5.0) - 1.0) / 2;
    double xL = b - k*(b - a);
    double xR = a + k*(b - a);
        
    while (b-a>eps)
    {
        if((*f)(n,n1,first,second,F,yy,yy_new,xL)<(*f)(n,n1,first,second,F,yy,yy_new,xR))
        {
            b = xR;
            xR = xL;
            xL = b - k*(b - a);
        }
        else
        {
            a = xL;
            xL = xR;
            xR = a + k * (b - a);
        }
    }
    return (a+b)/2;
    
}

double f_alpha(int n, int n1, int first[], int second[], double F[], double yy[], double yy_new[], double alpha)
{
    int i;
    
    for (i=1;i<=n1;i++)
        yy_new[i]=(1-alpha)*F[i]+alpha*yy[i];

    return criterion(n,first,second,yy_new);
}

void transfer(int first, int last, double a[], double b[])
{
    int    i;
    for (i = first; i<= last;i++)    b[i] = a[i];
}

double criterion(int n, int first[], int second[], double yy[])
{
    int i;
    double sum=0;
    
    for (i=1;i<=n;i++)
        sum -= log(yy[second[i]]-yy[first[i]]);
    
    return sum;
}


void gradient(int n, int n1, int first[], int second[], double yy[], double grad[])
{
    int i;
        
    for (i=0;i<=n1+1;i++)
        grad[i]=0;
    
    // grad contains minus the derivatives of the criterion function w.r.t. the y_i's.
    
    for (i=1;i<=n;i++)
    {
        if (yy[second[i]]-yy[first[i]]>0)
        {
            grad[first[i]] -= 1.0/(yy[second[i]]-yy[first[i]]);
            grad[second[i]] += 1.0/(yy[second[i]]-yy[first[i]]);
        }
    }
}

void weights(int n, int n1, int first[], int second[], double grad[], double w[])
{
    int i;
    
    for (i=1;i<=n1;i++)
        w[i]=0;
    
    for (i=1;i<=n;i++)
    {
        w[first[i]] += SQR(grad[first[i]]);
        w[second[i]] += SQR(grad[second[i]]);
    }
}


void cumsum(int n1, double yy[], double w[], double cumw[], double cs[], double grad[])
{
    int  i;
    
    cumw[0]=0;
    cs[0]=0;
    
    for (i=1;i<=n1;i++)
    {
        cumw[i] = cumw[i-1]+w[i];
        cs[i]   = cs[i-1]+w[i]*yy[i]+grad[i];
    }
}


void convexminorant(int n1, double cumw[], double cs[], double yy[])
{
    int    i,j,m;
    
    cumw[0]=0;
    cs[0]=0;
    yy[0]=0;
    
    for (i=1;i<=n1;i++)
    {
        yy[i] = (cs[i]-cs[i-1])/(cumw[i]-cumw[i-1]);
        if (yy[i-1]>yy[i])
        {
            j = i;
            while ((yy[j-1] > yy[i]) && (j>1))
            {
                j--;
                yy[i] = (cs[i]-cs[j-1])/(cumw[i]-cumw[j-1]);
                for (m=j;m<i;m++)
                    yy[m] = yy[i];
            }
        }
    }
    
    for (i=1;i<=n1;i++)
    {
        if (yy[i]<=0)
            yy[i]=0;
        if (yy[i]>=1)
            yy[i]=1;
    }
}

int fenchelviol(int n1, double yy[], double grad[], double tol, double *inprod, double *partsum)
{
    double    sum,sum2;
    int    i;
    int    fenchelvioltemp;
    
    fenchelvioltemp = 0;

    sum=sum2 = 0;
    
    for (i=1;i<=n1;i++)
    {
        sum += grad[i];
        if (sum < sum2)
            sum2 = sum;
    }
    
    sum=0;

    for (i=1;i<=n1;i++)
        sum += grad[i]*yy[i];
    
    *inprod = sum;
    *partsum = sum2;
    
    if ((fabs(sum) > tol) || (sum2 < -tol) ) fenchelvioltemp = 1;
    
    return fenchelvioltemp;
}

void isoreg(int n, int n1, int first[], int second[], double F[], double grad[], int *iterations)
{
    int i,iter;
    double *yy,*yy_new,alpha,inprod,partsum;
    double *minorant,*w,*cs,*cumw;
    double tol=1.0e-8;
    
    alpha=1;
        yy = new double[n1+2];
    yy_new = new double[n1+2];
    minorant = new double[n1+2];
    
    yy[0]=yy_new[0]=0.0;
    yy[n1+1]=yy_new[n1+1]=1;
    
    cs   = new double[n1+2];
    cumw    = new double[n1+2];
    w    = new double[n1+2];
    
    gradient(n,n1,first,second,F,grad);
    
    //for (i=1;i<=n1;i++)
        //printf("%5d  %15.10f\n",i,grad[i]);
    
    iter=0;
        
    while (fenchelviol(n1,F,grad,tol,&inprod,&partsum) && iter<1000)
    {
        iter++;
        transfer(1,n1,F,yy);
        
        weights(n,n1,first,second,grad,w);
        cumsum(n1,yy,w,cumw,cs,grad);
        convexminorant(n1,cumw,cs,yy);
        
        //for (i=1;i<=n1;i++)
            //printf("w_i's: %5d  %15.10f\n",i,w[i]);
        
        alpha = golden(n,n1,first,second,F,yy,yy_new,f_alpha);
 
        for (i=1;i<=n1;i++)
            F[i] = alpha*yy[i]+(1-alpha)*F[i];
        
        gradient(n,n1,first,second,F,grad);
                
        //printf("%5d  %15.10f  %15.10f   %15.10f\n",iter,inprod,partsum,alpha);
    }
    
    /*printf("\n");
    //for (i=1;i<=n;i++)
        //printf("%5d  %5d  %5d\n",i,first[i],second[i]);*/
    
    *iterations = iter;

    delete[] yy; delete[] yy_new;
    delete[] cs; delete[] cumw;  delete[] w; delete[] minorant;
    
    //for (i=1;i<=n;i++)
        //printf("%15.10f     %15.10f\n",cumw[i],cs[i]);
}
