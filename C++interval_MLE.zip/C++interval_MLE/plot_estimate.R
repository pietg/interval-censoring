     B<-read.table("MLE.txt")
	   x<-B[,1]
	   y<-B[,2]
	   
	   
	   C<-read.table("LS.txt")
	   x1<-C[,1]
	   y1<-C[,2]

	   
	   a<-3.035140901
   		b<-0.002619475
     	f <- function(x) {(1-exp(-x))/(1-exp(-2))}
     	x0 <-seq(0,2,by=0.01)
   		y0<-f(x0)
	   	
	   plot(c(-1000,-1000),xlim=c(0,2), ylim=c(0,max(y)), main= "",ylab="",xlab="",bty="n",las=1)
	   lines(x,y,lwd=2,col="red",lty=2,type='s')
	   lines(x1,y1,lwd=2,type='s',col="blue")
	   lines(x0,y0,lwd=2)
		
		
		
		
	
	    