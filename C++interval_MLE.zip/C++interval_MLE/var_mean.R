 	A<-read.table("mean.txt")
 	n=1000
 	b = n*var(A[,1])
 	 cat(b,"\n")

