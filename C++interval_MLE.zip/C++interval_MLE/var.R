 	A<-read.table("df.txt")

	n = 1000
	ngrid = 19
	
	variances <- matrix(0, nrow= ngrid, ncol= 2, byrow = FALSE)
	correlations <- matrix(0, nrow= ngrid, ncol= 2, byrow = FALSE)

for (i in 1: ngrid)
	{
		variances[i,1] = i*0.1
		variances[i,2] = n^(2/3)*var(A[,i])
		b = c(i*0.1,variances[i,2])
		cat(b,"\n")
	}
	
for (i in 1:9)
	{
		correlations[i,1] = i*0.1
		correlations[i,2] = cor(A[,i],A[,10+i])
		b = c(i*0.1, correlations[i,2])
		cat(b,"\n")
	}


