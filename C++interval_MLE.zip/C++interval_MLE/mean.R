	A<-read.table("mean.txt")
	
	m <- max(A[,1])
	
	pdf("BoxPlot_mean.pdf")
	boxplot(A,las=1)
    dev.off()
