//
//  data.cpp
//  interval_censoring_LS
//
//  Created by Piet Groeneboom on 15/08/2025.
//

#include "main.h"

void   data_exp(int n, double **data, int **delta, int seed)
{
    int    i,j;
    double u,v,w,s;
    
    std::mt19937_64 gen(seed);
    std::uniform_real_distribution<double> dis_unif(0,1);
    
    for (i=0;i<n;i++)
    {
        v = dis_unif(gen);
        w = dis_unif(gen);
        if (w<v)
        {
            s=w;
            w=v;
            v=s;
        }

        //u = dis_unif(gen);
        //u = -log(1-u+u*exp(-2));
        
        u = dis_unif(gen);
        
        data[i][0]=v;
        data[i][1]=w;
        
        for (j=0;j<=2;j++)
            delta[i][j]=0;
        
        if (u<=v)
        {
            delta[i][0] =1;
            data[i][1]=v;
            data[i][0]=0;
        }
        else
        {
            if (v<u && u<=w)
                delta[i][1]=1;
            else
            {
                delta[i][2]=1;
                data[i][0]=w;
                data[i][1]=2;
            }
        }
    }
}

/*void   data_exp(int n, double **data, int seed)
{
    int    i;
    double u,v,e;
    
    e=1;
    
    std::mt19937_64 gen(seed);
    std::uniform_real_distribution<double> dis_unif(0,1);
    
    for (i=0;i<n;i++)
    {
        e = 0.5+dis_unif(gen);
        v = e*dis_unif(gen);
        //v = 3*dis_unif(gen);
        //u= dis_unif(gen);
        u = dis_unif(gen);
        u = -log(1-u+u*exp(-2));
        data[i][1] = u + v;
        
        if (data[i][1]<=e)
            data[i][0]=0;
        else
            data[i][0]=data[i][1]-e;
    }
}*/

/*void   data_exp(int n, double a, double b, double M1, double M, double **data, double data_exit[], double data_incub[], int seed)
{
    int    i;
    double u,v,m;
    
    std::mt19937_64 gen(seed);
    std::uniform_real_distribution<double> dis_unif(0,1);
    std::uniform_int_distribution<int> dis1(1,M);
    
    for (i=0;i<n;i++)
    {
        //m=data3[i]=dis1(gen);
        //m= M*dis_unif(gen);
        m= 1+(M-1)*dis_unif(gen);
        
        data_exit[i]=m;
        v = dis_unif(gen)*m;
        
        u = dis_unif(gen);
        data_incub[i] = Weibull_inv(a,b,M1,u);
        //data_incub[i] = M1*u;
        
        data[i][1] = v+data_incub[i];
        
        if (data[i][1]<=m)
            data[i][0]=0;
        else
            data[i][0]=data[i][1]-m;
    }
}*/

void    getData_Lauer(FILE *in, int n, double data_exit_L[], double data_exit_R[], double data_symp_L[], double data_symp_R[])
{
    int i,j;
    rewind(in);
    
    for (i=0;i<n;i++)
        fscanf(in,"%d   %lf  %lf   %lf  %lf" ,&j,&data_exit_L[i],&data_exit_R[i],&data_symp_L[i],&data_symp_R[i]);
}

void    getData_Lauer2(FILE *in, int n, double data1[], double data2[], double data3[])
{
    int i;
    rewind(in);
    
    for (i=0;i<n;i++)
        fscanf(in,"%lf  %lf   %lf",&data1[i],&data2[i],&data3[i]);
}

void    get_df(FILE *in, int NumIt, int ngrid, double **data)
{
    int i,j;
    
    rewind(in);
    for (i=0;i<NumIt;i++)
    {
        for (j=1;j<=ngrid;j++)
            fscanf(in,"%lf",&data[i][j]);
    }
}

void    getData(FILE *in, int n, double **data)
{
    int i;
    
    rewind(in);
    for (i=0;i<n;i++)
        fscanf(in,"%lf  %lf",&data[i][0],&data[i][1]);
}

void data_infect(int n, double data3[], double data_infection[], int seed)
{
    int    i;
    double j;
    
    std::uniform_real_distribution<double> dis_unif(0.0,1.0);
    std::mt19937_64 gen(seed);
    
    for (i=0;i<n;i++)
    {
        j = data3[i];
        data_infection[i] = j*dis_unif(gen);
    }
}

double data_smooth(int m, double M1, double tt[], double pp[], double h)
{
    int j,seed;
    double v,w;
    
    w=1;
    seed = rand();
    std::mt19937_64 gen(seed);
    std::uniform_real_distribution<double> dis_unif(0.0,1.0);

    
    v = dis_unif(gen);
    w = golden(0,fmin(M1,tt[m]+h),m,tt,pp,v,h,criterion2);
    
    /*j=0;
    while (j<1)
    {
        w=M1*dis_unif(gen);
        v=dis_unif(gen);
        c = dens_estimate(0.0,M1,m,tt,pp,w,h);
        if (v<c/10)
            j++;
    }*/
    
    return w;
}

void reduce_variables(int n, double M1, double data_exit[], double **data, double reduced_var[])
{
    int i,j;
    double a,b;
    
    for (i=0;i<n;i++)
    {
        j=0;
        a=data_exit[i];
        b=data[i][1];
        while (a<b)
        {
            j++;
            a += data_exit[i];
        }
        reduced_var[i]=b-j*data_exit[i];
    }
}

void data_bootstrap(int n, int m, double M1, double M, double data_exit[], double reduced_var[], double **data, double **bootstrap_data, double tt[], double pp[], double h, int seed)
{
    int    i,j;
    double u;
    
    std::mt19937_64 gen(seed);
    std::uniform_real_distribution<double> dis_unif(0,1);
    
    for (i=0;i<n;i++)
    {
        u=dis_unif(gen);
        j=0;
        while (bdf(0,M1,m,tt,pp,reduced_var[i]+j*data_exit[i],h)<u)
            j++;
        bootstrap_data[i][1] = fmin(M1+M,reduced_var[i]+j*data_exit[i]);
        bootstrap_data[i][0] = fmax(0,reduced_var[i]+(j-1)*data_exit[i]);
    }
}


void data_bootstrap(int n, int m, double M1, double data_exit[], double **bootstrap_data,double tt[], double pp[], double h, int seed)
{
    int    i;
    double u,v;
    
    std::mt19937_64 gen(seed);
    std::uniform_real_distribution<double> dis_unif(0,1);
                
    for (i=0;i<n;i++)
    {
        u=dis_unif(gen);
        v = data_exit[i]*u+data_smooth(m,M1,tt,pp,h);
        
        if (v > data_exit[i])
        {
            bootstrap_data[i][0]= v-data_exit[i];
            bootstrap_data[i][1]=v;
        }
        else
        {
            bootstrap_data[i][0]=0;
            bootstrap_data[i][1]=v;
        }
    }
}


void data_bootstrap(int n, int m, double **data, double **data_bootstrap, int seed)
{
    int    i,j;
    
    std::mt19937_64 gen(seed);
    std::uniform_int_distribution<int> dis(0,n-1);
    
    for (i=0;i<m;i++)
    {
        j=dis(gen);
        data_bootstrap[i][0]=data[j][0];
        data_bootstrap[i][1]=data[j][1];
    }
}


