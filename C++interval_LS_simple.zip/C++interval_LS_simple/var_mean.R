 	A<-read.table("mean.txt")
 	 n=10000
 	b = n*var(A[,1])
 	cat(b,"\n")

