//
//  icm_LS1.cpp
//  interval_censoring_LS
//
//  Created by Piet Groeneboom on 27/08/2025.
//

#include "main.h"

void gradient(int n, int delta[], int first[], int second[], double yy[], double grad[]);

void transfer(int first, int last, double a[], double b[])
{
    int    i;
    for (i = first; i<= last;i++)    b[i] = a[i];
}

double criterion(int n, int delta[], int first[], int second[], double yy[])
{
    int i;
    double sum=0;
    
    for (i=1;i<=n;i++)
    {
        sum += SQR(yy[first[i]]-delta[first[i]])/2+SQR(yy[second[i]]-delta[first[i]]-delta[second[i]])/2;
    }
    
    return sum;
}


/*void gradient(int n, int delta[], int first[], int second[], double yy[], double grad[])
{
    int i;
        
    for (i=1;i<=n;i++)
        grad[i]=grad[n+i]=0;
    // grad contains minus(!) the derivatives of the criterion function w.r.t. the y_i's.
    
    for (i=1;i<=n;i++)
    {
        grad[first[i]] += delta[first[i]]-yy[first[i]];
        grad[second[i]] += delta[first[i]]+delta[second[i]]-yy[second[i]];
    }
}*/

void gradient(int n, int delta[], int first[], int second[], double yy[], double grad[])
{
    int i;
        
    for (i=1;i<=2*n;i++)
        grad[i]=0;
    
    for (i=1;i<=n;i++)
    {
        grad[first[i]] += delta[first[i]];
        grad[second[i]] += delta[first[i]]+delta[second[i]];
    }
}

void weights(int n, double yy[], double w[])
{
    int i;
    
    for (i=1;i<=2*n;i++)
        w[i]=1;
}


void cumsum(int n, double yy[], double w[], double cumw[], double cs[], double grad[])
{
    int  i;
    
    cumw[0]=0;
    cs[0]=0;
    
    for (i=1;i<=2*n;i++)
    {
        cumw[i] = cumw[i-1]+w[i];
        cs[i]   = cs[i-1]+grad[i];
    }
}


void convexminorant(int n, double cumw[], double cs[], double yy[])
{
    int    i,j,m;
    
    cumw[0]=0;
    cs[0]=0;
    yy[0]=0;
    
    for (i=1;i<=2*n;i++)
    {
        yy[i] = (cs[i]-cs[i-1])/(cumw[i]-cumw[i-1]);
        if (yy[i-1]>yy[i])
        {
            j = i;
            while ((yy[j-1] > yy[i]) && (j>1))
            {
                j--;
                yy[i] = (cs[i]-cs[j-1])/(cumw[i]-cumw[j-1]);
                for (m=j;m<i;m++)
                    yy[m] = yy[i];
            }
        }
    }
    
    for (i=1;i<=2*n;i++)
    {
        if (yy[i]<=0)
            yy[i]=0;
        if (yy[i]>=1)
            yy[i]=1;
    }
}

int fenchelviol(int n, double yy[], double grad[], double tol, double *inprod, double *partsum)
{
    double    sum,sum2;
    int    i;
    int    fenchelvioltemp;
    
    fenchelvioltemp = 0;
    
    sum=sum2 = 0;
    
    for (i=1;i<=2*n;i++)
    {
        sum += grad[i];
        if (sum < sum2)
            sum2 = sum;
    }
    
    for (i=1;i<=2*n;i++)
        sum += grad[i]*yy[i];
    
    *inprod = sum;
    *partsum = sum2;
    
    if ((fabs(sum) > tol) || (sum2 < -tol) ) fenchelvioltemp = 1;
    
    return fenchelvioltemp;
}

void isoreg(int n, int delta[], int first[], int second[], double data0[], double F[], double grad[], int *iterations)
{
    int i,iter;
    double *yy,*yy_new,alpha,inprod,partsum;
    double *minorant,*w,*cs,*cumw,sum;
    double tol=1.0e-8;
    FILE    *outputfile = NULL;
    
    alpha=1;
    
    yy = new double[2*n+2];
    yy_new = new double[2*n+2];
    minorant = new double[2*n+2];
    
    yy[0]=yy_new[0]=0.0;
    yy[2*n+1]=yy_new[2*n+1]=1;
    
    cs   = new double[2*n+2];
    cumw    = new double[2*n+2];
    w    = new double[2*n+2];
        
    gradient(n,delta,first,second,F,grad);
    iter=0;
    
    weights(n,yy,w);
    cumsum(n,yy,w,cumw,cs,grad);
    convexminorant(n,cumw,cs,yy);
    
    for (i=1;i<=2*n;i++)
        F[i]=yy[i];
    

    outputfile=fopen("W_process.txt","w");
    rewind(outputfile);
    
    sum=0;
    for (i=1;i<2*n;i++)
    {
        sum += grad[i];
        //if (fabs(sum)<tol)
            fprintf(outputfile,"%15.10f     %15.10f\n",data0[i],sum);
    }
    
    fclose(outputfile);
        
    minorant[0]=0;
    outputfile=fopen("minorant.txt","w");
    rewind(outputfile);
    
    for (i=0;i<=2*n;i++)
    {
        if (i>0)
            minorant[i]= minorant[i-1]+yy[i]*w[i];
        fprintf(outputfile,"%5.0f   %5.0f   %15.10f %5d\n",cumw[i],cs[i],minorant[i],delta[i]);
    }
        
    fclose(outputfile);
    
    *iterations = iter;
    
    delete[] yy; delete[] yy_new;
    delete[] cs; delete[] cumw;  delete[] w; delete[] minorant;
}
