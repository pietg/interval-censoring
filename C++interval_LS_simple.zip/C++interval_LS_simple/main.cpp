

//  main.cpp
//  Interval censoring using LS estimators
//
//  Created by Piet Groeneboom on 15/08/2025.
//  Copyright © 2020 Piet Groeneboom. All rights reserved.
//

#include "main.h"

int main(int argc, const char * argv[]) {
    
    int i,iter,iterations,count,ngrid,**delta;
    int NumIt,seed;
    int     k,n,m;
    double  *tt,t0,value_function;
    double  *F,*yy,mean1;
    double  **data,**df_on_grid;
    double  *df,*pp,*grid;
    double  *mean,*var;
    FILE    *inputfile = NULL;
    FILE    *outputfile = NULL;
    FILE    *df_file = NULL;
    FILE    *mean_file = NULL;
    
    n=1000;
    NumIt=10000;
    seed=1;
    
    iterations=0;
    
    value_function=0;
    m=1;
    std::uniform_real_distribution<double> dis(0.0,1.0);
    std::mt19937_64 gen(seed);
    
    ngrid=9;
    grid = new double[ngrid+1];
    for (i=0;i<=ngrid;i++)
        grid[i] = i*0.1;
    
    mean = new double[ngrid+1];
    var = new double[ngrid+1];
    
    delta = new int *[n];
    for (i=0;i<n;i++)
        delta[i]= new int[3];
    
    data = new double *[n];
    for (i=0;i<n;i++)
        data[i]= new double[2];
    
    df_on_grid = new double *[NumIt+1];
    for (i=0;i<NumIt+1;i++)
        df_on_grid[i]= new double[ngrid+1];
    
    yy =  new double[2*n+2];
    F =  new double[2*n+2];
    df =  new double[ngrid+1];

    pp = new double[2*n+2];
    tt = new double[2*n+2];
    
    df_file=fopen("df.txt","w");
    rewind(df_file);
    
    mean_file=fopen("mean.txt","w");
    rewind(mean_file);
        
    count = 0; // counts converged iterations
    
    for (iter=0;iter<NumIt;iter++)
    {
        seed++;
        //data_exp(n,data,seed);
        data_exp(n,data,delta,seed);
        
        m = compute_LS(n,data,delta,F,tt,pp,&iterations);
                
        if (iterations < 1000)
        {
            count++;
            
            for (k=1;k<=ngrid;k++)
            {
                t0 = grid[k];
                for (i=1;i<=m;i++)
                {
                    if (tt[i-1]<= t0 && tt[i]>t0)
                        value_function = F[i-1];
                }
                
                if (tt[m]<= t0)
                    value_function = F[m];
                
                df[k] = value_function;
                df_on_grid[count][k] = df[k];
            }
            
            for (k=1;k<=ngrid;k++)
                fprintf(df_file,"%15.10f",df[k]);
            fprintf(df_file,"\n");
            
        }
        
        mean1=0;
        for (i=1;i<=m;i++)
            mean1 += (1-F[i-1])*(tt[i]-tt[i-1]);
                
        fprintf(mean_file,"%15.10f\n",mean1);
        printf("%5d\n",iter+1);
    }

    fclose(df_file);
    fclose(mean_file);
    
    printf("\ncount = %d\n\n",count);
            
    mean_variance(count,ngrid,df_on_grid,mean,var);
    
    outputfile=fopen("Variances_LS.txt","w");
    rewind(outputfile);
    
    for (i=1;i<=ngrid;i++)
        fprintf(outputfile,"%5.2f     %15.10f\n",grid[i],pow(n,2.0/3)*var[i]);
    
    fclose(outputfile);
    
    outputfile=fopen("LS.txt","w");
    rewind(outputfile);
    
    for (i=0;i<=m;i++)
        fprintf(outputfile,"%15.10f     %15.10f\n",tt[i],F[i]);
        
    fclose(outputfile);
    
    outputfile=fopen("data.txt","w");
    rewind(outputfile);
    
    for (i=0;i<n;i++)
        fprintf(outputfile,"%15.10f     %15.10f  %5d   %5d %5d\n",data[i][0],data[i][1]
                ,delta[i][0],delta[i][1],delta[i][2]);
    fclose(outputfile);
    
    for (i=0;i<n;i++)
        delete[] data[i];
    delete[] data;
    
    delete[] tt; delete[] pp; delete[] F;

    return 0;
}

