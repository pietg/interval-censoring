//
//  data.cpp
//  interval_censoring_LS
//
//  Created by Piet Groeneboom on 15/08/2025.
//

#include "main.h"

/*void   data_exp(int n, double **data, int **delta, int seed)
{
    int    i;
    double u,v,e;
    
    e=1;
    
    std::mt19937_64 gen(seed);
    std::uniform_real_distribution<double> dis_unif(0,1);
    
    for (i=0;i<n;i++)
        delta[i][0]=delta[i][1]=delta[i][2]=0;
    
    for (i=0;i<n;i++)
    {
        e = 0.5+dis_unif(gen);
        v = e*dis_unif(gen);
        //v = 3*dis_unif(gen);
        //u= dis_unif(gen);
        u = dis_unif(gen);
        u = -log(1-u+u*exp(-2));
        data[i][1] = u + v;
        
        if (data[i][1]<=e)
        {
            data[i][0]=0;
            delta[i][0]=1;
        }
        else
        {
            if (data[i][1]<2.5)
            {
                delta[i][1]=1;
                data[i][0]=data[i][1]-e;
            }
            else
            {
                delta[i][2]=1;
                //data[i][1]=data[i][1]-e;
                data[i][0]=data[i][1]-e;
                data[i][1]=2;
                //data[i][1]=2;
                //data[i][0]=data[i][1];
                //data[i][0]=0;
            }
        }
    }
}*/


void   data_exp(int n, double **data, int **delta, int seed)
{
    int    i,j;
    double u,v,w,s;
    
    std::mt19937_64 gen(seed);
    std::uniform_real_distribution<double> dis_unif(0,1);
    
    for (i=0;i<n;i++)
    {
        v = dis_unif(gen);
        w = dis_unif(gen);
        if (w<v)
        {
            s=w;
            w=v;
            v=s;
        }

        //u = dis_unif(gen);
        //u = -log(1-u+u*exp(-2));
        
        u=dis_unif(gen);
        
        data[i][0]=v;
        data[i][1]=w;
        
        for (j=0;j<=2;j++)
            delta[i][j]=0;
        
        if (u<=v)
            delta[i][0] =1;
        else
        {
            if (v<u && u<=w)
                delta[i][1]=1;
            else
                delta[i][2]=1;
        }
    }
}


void   data_exp(int n, double **data, int seed)
{
    int    i;
    double u,v,e;
    
    e=1;
    
    std::mt19937_64 gen(seed);
    std::uniform_real_distribution<double> dis_unif(0,1);
    
    for (i=0;i<n;i++)
    {
        e = 0.5+dis_unif(gen);
        v = e*dis_unif(gen);
        //v = 3*dis_unif(gen);
        //u= dis_unif(gen);
        u = dis_unif(gen);
        u = -log(1-u+u*exp(-2));
        data[i][1] = u + v;
        
        if (data[i][1]<=e)
            data[i][0]=0;
        else
            data[i][0]=data[i][1]-e;
    }
}


/*void   data_exp(int n, double **data, int seed)
{
    int    i;
    double u,v,e;
    
    e=1;
    
    std::mt19937_64 gen(seed);
    std::uniform_real_distribution<double> dis_unif(0,1);
    
    for (i=0;i<n;i++)
    {
        e = 0.5+dis_unif(gen);
        v = e*dis_unif(gen);
        //v = 3*dis_unif(gen);
        //u= dis_unif(gen);
        u = dis_unif(gen);
        u = -log(1-u+u*exp(-2));
        data[i][1] = u + v;
        
        if (data[i][1]<=e)
            data[i][0]=0;
        else
            data[i][0]=data[i][1]-e;
    }
}*/


/*void   data_exp(int n, double a, double b, double M1, double M, double **data, double data_exit[], double data_incub[], int seed)
{
    int    i;
    double u,v,m;
    
    std::mt19937_64 gen(seed);
    std::uniform_real_distribution<double> dis_unif(0,1);
    std::uniform_int_distribution<int> dis1(1,M);
    
    for (i=0;i<n;i++)
    {
        //m=data3[i]=dis1(gen);
        //m= M*dis_unif(gen);
        m= 1+(M-1)*dis_unif(gen);
        
        data_exit[i]=m;
        v = dis_unif(gen)*m;
        
        u = dis_unif(gen);
        data_incub[i] = Weibull_inv(a,b,M1,u);
        //data_incub[i] = M1*u;
        
        data[i][1] = v+data_incub[i];
        
        if (data[i][1]<=m)
            data[i][0]=0;
        else
            data[i][0]=data[i][1]-m;
    }
}*/

void    getData_Lauer(FILE *in, int n, double data_exit_L[], double data_exit_R[], double data_symp_L[], double data_symp_R[])
{
    int i,j;
    rewind(in);
    
    for (i=0;i<n;i++)
        fscanf(in,"%d   %lf  %lf   %lf  %lf" ,&j,&data_exit_L[i],&data_exit_R[i],&data_symp_L[i],&data_symp_R[i]);
}

void    getData_Lauer2(FILE *in, int n, double data1[], double data2[], double data3[])
{
    int i;
    rewind(in);
    
    for (i=0;i<n;i++)
        fscanf(in,"%lf  %lf   %lf",&data1[i],&data2[i],&data3[i]);
}

void    get_df(FILE *in, int NumIt, int ngrid, double **data)
{
    int i,j;
    
    rewind(in);
    for (i=0;i<NumIt;i++)
    {
        for (j=1;j<=ngrid;j++)
            fscanf(in,"%lf",&data[i][j]);
    }
}

void    getData(FILE *in, int n, double **data)
{
    int i;
    
    rewind(in);
    for (i=0;i<n;i++)
        fscanf(in,"%lf  %lf",&data[i][0],&data[i][1]);
}

void data_infect(int n, double data3[], double data_infection[], int seed)
{
    int    i;
    double j;
    
    std::uniform_real_distribution<double> dis_unif(0.0,1.0);
    std::mt19937_64 gen(seed);
    
    for (i=0;i<n;i++)
    {
        j = data3[i];
        data_infection[i] = j*dis_unif(gen);
    }
}


